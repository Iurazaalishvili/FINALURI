package com.btust.firebaseproject1

class contactInfo(val id: String?, val name: String, val number: String, val rating: Int)